<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact us</title>
</head>
<body>
    <p>Hello, </p>
    <p>You a new email from <?php echo e($details['fname']); ?>

        <?php if(!empty($details['lname'])): ?>
            <?php echo e($details['lname']); ?>

        <?php endif; ?>
    </p>

    <ul>
        <li><strong>Email: </strong> <?php echo e($details['email']); ?></li>
        <li>
            <strong>Subject: </strong> 
            <?php if(!empty($details['subject'])): ?>
                <?php echo e($details['subject']); ?>

            <?php endif; ?>
        </li>
        <li><strong>Message: </strong> <?php echo e($details['message']); ?></li>
    </ul>
</body>
</html><?php /**PATH C:\inetpub\wwwroot\Vinnie\neco\resources\views/mail/contactus.blade.php ENDPATH**/ ?>