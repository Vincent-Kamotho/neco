<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Appointment Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/booking/fonts/linearicons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/booking/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/booking/vendor/date-picker/css/datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/booking/css/style.css')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/frontend/images/neco-logo.png')); ?>">
    <meta name="robots" content="noindex, follow">
    
</head>

<body>
    <div class="wrapper">
        <div class="inner" >
            <form action ="<?php echo e(url('request-appointment')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3>Book an Appointment</h3>
                <?php if(session('error')): ?>
                   <div class="alert alert-danger" style="color:red;">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success" style="color:#2b1b7588">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php echo e(session()->forget('success')); ?>

                <?php endif; ?>
                <div class="form-row">
                    <div class="form-wrapper">
                        <label for="name">Names *</label>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Your Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-wrapper">
                        <label for="phone">Phone *</label>
                        <input type="text" class="form-control" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" placeholder="0712345678">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-wrapper">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>
                <div class="form-row">
                    <div class="form-wrapper">
                        <label for="dp1">Date *</label>
                        
                        
                        <input type="date" class="form-control" name="date" value="<?php echo e(old('date')); ?>">
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-wrapper">
                        <label for>Time</label>
                        <input type="time" class="form-control timepicker-here" data-language="en" value="<?php echo e(old('time')); ?>" name="time">
                        <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row last">
                    <div class="form-wrapper">
                        <label for> Issue *</label>
                        <select name="issue" id="issue" value="<?php echo e(old('issue')); ?>" class="form-control">
                            <option value="">Select Option</option>
                            <option value="Depression Treatment">Depression Treatment</option>
                            <option value="Personal Problem">Personal Problem</option>
                            <option value="Relationship Problem">Relationship Problem</option>
                            <option value="Family Problem">Family Problem</option>
                            <option value="Couples Counselling">Couples Counselling</option>
                            <option value="Business Problem">Business Problem</option>
                            <option value="Other">Other</option>
                        </select>
                        <?php $__errorArgs = ['issue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500" style="color: red;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <i class="zmdi zmdi-chevron-down"></i>
                    </div>    
                </div>
                <button style="border-radius: 35px;">
                    <span>Submit</span>
                </button>
            </form>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/frontend/booking/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/booking/vendor/date-picker/js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/booking/vendor/date-picker/js/datepicker.en.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/booking/js/main.js')); ?>"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    
</body>



</html><?php /**PATH C:\inetpub\wwwroot\Vinnie\neco\resources\views/frontend/appointmentbooking.blade.php ENDPATH**/ ?>